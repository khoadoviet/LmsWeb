'use strict';
(function() {
  const API_URL = '/api/all/courses';

  window.addEventListener('load', init);

  /**
   * TODO - setup the sign-in button on initial page load
   */
  function init() {
    fetch(API_URL,{
        method: "GET"
    })
    .then(statusCheck)
    .then(resp => resp.json())
    .then(addEntry)
    .catch(console.log);

  
    // TODO
  }

  /**
   * TODO
   * signIn - Signs the user in based on username and password inputs
   */
   
   function addEntry(rows) {
    let resgister = id("courses")
    for (let i = 0; i < rows.length; i++) {
        let CourseName = rows[i]["CourseName"];
        
        let oneCourse = document.createElement("div");
        let properties = document.createElement("div");
        let header = document.createElement("div");
        let img = document.createElement("img");
        let buttons = document.createElement("div");
        
        let divEnroll = document.createElement("div")
        let leaveButton = document.createElement("button");
        let body = document.createElement("div");
        let amount = document.createElement("h3");
        let rate = document.createElement("div");
        let star1 = document.createElement("small");
        let star2= document.createElement("small");
        let star3 = document.createElement("small");
        let star4 = document.createElement("small");
        let star5 = document.createElement("small");
        let cmt = document.createElement("h5");
        let end = document.createElement("div");
        


        //leave course
        // leaveButton.href = "/mycourses.html";
        leaveButton.className = "flex-shrink-0 btn btn-sm btn-primary px-3";
        leaveButton.id = "enroll"
        leaveButton.style = "border-radius: 0 30px 30px 0;";
        leaveButton.innerText = "Enroll Course";
        divEnroll.id = "enrollCourse";
        divEnroll.className = CourseName;

        // all button
        buttons.className = "w-100 d-flex justify-content-center position-absolute bottom-0 start-0 mb-4";
        divEnroll.appendChild(leaveButton)
        buttons.appendChild(divEnroll);
        
        img.className = "img-fluid";
        img.src = "img/"+ CourseName + ".jpg";
        img.alt = "";

        header.className = "position-relative overflow-hidden";
        header.appendChild(img);
        header.appendChild(buttons);
        // body
        cmt.className = "mb-4";
        cmt.innerHTML= CourseName + " for Beginners";
        star1.className = "fa fa-star text-primary";
        star2.className = "fa fa-star text-primary";
        star3.className = "fa fa-star text-primary";
        star4.className = "fa fa-star text-primary";
        star5.className = "fa fa-star text-primary";
        rate.className = "mb-3";
        // 5*
        rate.appendChild(star1);
        rate.appendChild(star2);
        rate.appendChild(star3);
        rate.appendChild(star4);
        rate.appendChild(star5);
        amount.className = "mb-0";
        amount.innerText = "4.000.000 VND";
        body.className = "text-center p-4 pb-0";
        body.appendChild(amount);
        body.appendChild(rate);
        body.appendChild(cmt);
        // end
        


        properties.className = "course-item bg-light";
        properties.appendChild(header);
        properties.appendChild(body);
        properties.appendChild(end);
        oneCourse.className = "col-lg-4 col-md-6 wow fadeInUp";
        oneCourse.appendChild(properties);
        resgister.appendChild(oneCourse);

      }

     document.querySelectorAll("#enroll").forEach((e) => {
      e.addEventListener("click",enroll);
      e.myParam = rows;
   });
  }


function enroll(e){
  let target = e.target;
    
    let p = target.parentElement;
    let p1 = p.parentElement;
    console.log(p1)
    let a = p1.children[0].className;
    console.log(a)
    let rows = e.target.myParam;
    let cID = ""
    for(let i =0; i< rows.length; i++) {
      let CourseName = rows[i]["CourseName"];
        if(CourseName == a){
          cID = rows[i]["CourseID"];
        }
    }
    let formBody = new FormData();
      formBody.append("CourseID",cID);
        fetch(API_URL,{
          method: "POST",
          body: formBody
        })
        .then(statusCheck)
        .then(resp => resp.text())
        .then(checkResult)
        .catch(console.log)
  
}

function checkResult(result){
  console.log(result);
  if(result === "true"){
    alert( "enroll course successfully");
    window.location.href = 'mycourses.html';
    
  } else {
    
    alert("cannot not leave course");
    window.location.href = 'mycourses.html';
    
  }
  } 

  /* ------------------------------ Helper Functions  ------------------------------ */

  /**
   * Helper function to return the response's result text if successful, otherwise
   * returns the rejected Promise result with an error status and corresponding text
   * @param {object} res - response to check for success/error
   * @return {object} - valid response if response was successful, otherwise rejected
   *                    Promise result
   */
  async function statusCheck(res) {
    if (!res.ok) {
      throw new Error(await res.text());
    }
    return res;
  }

  /**
   * Returns the element that has the ID attribute with the specified value.
   * @param {string} id - element ID
   * @return {object} DOM object associated with id.
   */
  function id(id) {
    return document.getElementById(id);
  }

  /**
   * Returns the element that has the matches the selector passed.
   * @param {string} selector - selector for element
   * @return {object} DOM object associated with selector.
   */
  function qs(selector) {
    return document.querySelector(selector);
  }
})();
