'use strict';
(function() {
  const API_URL = '/api/register';

  window.addEventListener('load', init);

  function init() {
    let action =  id("Register");
    action.addEventListener('submit', function(e){
        e.preventDefault();
        let username = id("form3Example1c").value;
        let password = id("form3Example4c").value;
        let reupPassword = id("form3Example4cd").value;
        signUp(username,password,reupPassword);
      });
  
  }
   function signUp(u,p,rp) {
    if(p != rp){
        alert("wrong confirm password please enter password again")
        id("form3Example4c").value = "";
        id("form3Example4cd").value = "";
    } else{
       let formBody = new FormData();
    formBody.append("Username",u);
    formBody.append("Password",p);
      
      fetch(API_URL,{
        method: "POST",
        body: formBody
      })
      .then(statusCheck)
      .then(resp => resp.text())
      .then(getResult)
      .catch(console.log)
    }
   
  }
  function getResult(result){
  console.log(result)  
  if(result === "true"){
      alert("register successfully, please login to your account")
       window.location.href = 'login.html';
  } else{
    alert("please enter again username and password");
    window.location.href = 'register.html';
  }
 
  }
  /* ------------------------------ Helper Functions  ------------------------------ */

  /**
   * Helper function to return the response's result text if successful, otherwise
   * returns the rejected Promise result with an error status and corresponding text
   * @param {object} res - response to check for success/error
   * @return {object} - valid response if response was successful, otherwise rejected
   *                    Promise result
   */
  async function statusCheck(res) {
    if (!res.ok) {
      throw new Error(await res.text());
    }
    return res;
  }

  /**
   * Returns the element that has the ID attribute with the specified value.
   * @param {string} id - element ID
   * @return {object} DOM object associated with id.
   */
  function id(id) {
    return document.getElementById(id);
  }

  /**
   * Returns the element that has the matches the selector passed.
   * @param {string} selector - selector for element
   * @return {object} DOM object associated with selector.
   */
  function qs(selector) {
    return document.querySelector(selector);
  }
})();