'use strict';
(function() {
  const API_URL = './api/login';

  window.addEventListener('load', init);

  function init() {
   
    id("Sign-Up").addEventListener("submit", function(e){
      e.preventDefault();
      let username = id("form2Example11").value;
      let password = id("form2Example22").value;
      Login(username,password)
      
    });
  }

  function Login(u,p) {
    let formBody = new FormData();
    formBody.append("Username",u);
    formBody.append("Password",p);
    fetch(API_URL, {
      
      method: "POST",
      body : formBody
    })
    .then(statusCheck)
    .then(resp => resp.text())
    .then(showResult)
    .catch(console.log)
  }

  function showResult(result) {
    
      
    if (result === "true") {
      let loading = document.querySelector("#loading");
      let out = `
      <div class="spinner">
      <span>L</span>
      <span>O</span>
      <span>A</span>
      <span>D</span>
      <span>I</span>
      <span>N</span>
      <span>G</span>
    </div>`;
    loading.innerHTML = out;


      // loading.appendChild(div);
      let time = 0;
      let t = setInterval(function() {
        if (time == 0) {
          time++;
        } else {
          time++;
          if (time == 3) {
            clearInterval(t);
            setTimeout(() => {
              window.location.href = 'mycourses.html';
            }, 1000);
          }
        }
      },1000)
    } else {
      alert("username or password is incorrect");
      window.location.href = 'login.html';
  }
    }
  /* ------------------------------ Helper Functions  ------------------------------ */

  /**
   * Helper function to return the response's result text if successful, otherwise
   * returns the rejected Promise result with an error status and corresponding text
   * @param {object} res - response to check for success/error
   * @return {object} - valid response if response was successful, otherwise rejected
   *                    Promise result
   */
  async function statusCheck(res) {

    if (!res.ok) {
      throw new Error(await res.text());
    }
    return res;
  }

  /**
   * Returns the element that has the ID attribute with the specified value.
   * @param {string} id - element ID
   * @return {object} DOM object associated with id.
   */
  function id(id) {
    return document.getElementById(id);
  }

  /**
   * Returns the element that has the matches the selector passed.
   * @param {string} selector - selector for element
   * @return {object} DOM object associated with selector.
   */
  function qs(selector) {
    return document.querySelector(selector);
  }
})();