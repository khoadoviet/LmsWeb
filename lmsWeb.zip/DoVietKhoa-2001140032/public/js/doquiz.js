'use strict';
(function() {
  const API_URL = '/api/course/:courseid/doquiz/:quizid';

  window.addEventListener('load', init);

  function init() {
    id("Quiz").addEventListener('submit', function(e){
      e.preventDefault();
      alert("click");
    });
    fetch(API_URL,{
      method:"GET"
    })
    .then(statusCheck)
    .then(resp => resp.json())
    .then(addQuiz)
    .catch(console.log);
  }

  function addQuiz(rows) {
    let Quiz = id("Quiz");
    for (let i = 0; i < rows.length; i++) {
      let Question = rows[i]["Question"];
      let Answer = rows[i]["Answer"];
      let div = document.createElement("div");
      let b = document.createElement("b");
      div.id = "listQuestions";
      b.className = "QuestionName";
      b.innerText = "Question "+(i+1)+"\n" + Question;
      div.appendChild(b);
      for(let j = 0; j < Answer.length;j++) {
        let ans = Answer[j]["Answer"];
        let p = document.createElement("p")
        let inputAns = document.createElement("input")
        inputAns.type = "radio";
        
        inputAns.name = Question;
        inputAns.value = ans;
        inputAns.className = "Answer";
        p.appendChild(inputAns);
        let a = document.createElement("a");
        a.innerText = ans;
        a.id = "Answer";
        p.appendChild(a);
        div.appendChild(p);
      }
      Quiz.appendChild(div);
    }
    let submit = document.createElement("input");
    submit.type = "button"
    submit.value = "Submit"
    submit.id = "submit"
    submit.className = "btn btn-outline-primary"
    Quiz.appendChild(submit);

    id("submit").addEventListener('click', function(e){
      e.preventDefault();
      e.myParam = rows;
      submit.disabled = true;
      
      var answers = document.forms[0];
      var getAnswers = [];
      var i;
      for(i = 0;i<answers.length;i++) {
        if(answers[i].checked) {
          let Questions = answers[i].name;
          let ansOfUser = answers[i].value;
          getAnswers.push({Questions : Questions, ansOfUser : ansOfUser})
        }
      }
      
      submitAns(e,getAnswers);
    });
  }

  function submitAns(e,getAnswers) {
    let rows = e.myParam;
    let userChoices = [];
    for(let i = 0; i < rows.length;i++) {
      for(let j = 0; j < getAnswers.length;j++) {
        if(getAnswers[j]['Questions'] == rows[i]["Question"]) {
          let QuestionID = rows[i]["QuestionID"];
          let answer = rows[i]["Answer"];
          let AnswerID = "";
          for(let k = 0;k < answer.length;k++) {
            if(answer[k]["Answer"] == getAnswers[j]["ansOfUser"]){
              AnswerID = answer[k]["AnswersID"];
            }
          }
          userChoices.push({QuestionID: QuestionID, AnswerID: AnswerID});
        }
      }
    }
    userChoices = JSON.stringify(userChoices)
    let form = new FormData();
    form.append("answer", userChoices);
      fetch(API_URL,{
        method: "POST",
        body: form
      })
      .then(statusCheck)
      .then(resp => resp.text())
      .then(submit)
      .catch(console.log)
  }
  function submit(result) {
    let total = id("total result");
    let div = id("result");
    div.className = "alert alert-success";
    div.innerText = "Your mark is " + result * 2 + "/10";
    total.appendChild(div);
    let doAgain = document.createElement("input");
    doAgain.type = "button"
    doAgain.value = "Do test again"
    doAgain.id = "doAgain"
    doAgain.className = "btn btn-outline-primary"
    total.appendChild(doAgain);
    id("doAgain").addEventListener('click', function(){
      window.location.href = 'doquiz.html';
    });
  }

  /* ------------------------------ Helper Functions  ------------------------------ */

  /**
   * Helper function to return the response's result text if successful, otherwise
   * returns the rejected Promise result with an error status and corresponding text
   * @param {object} res - response to check for success/error
   * @return {object} - valid response if response was successful, otherwise rejected
   *                    Promise result
   */
  async function statusCheck(res) {
    if (!res.ok) {
      throw new Error(await res.text());
    }
    return res;
  }

  /**
   * Returns the element that has the ID attribute with the specified value.
   * @param {string} id - element ID
   * @return {object} DOM object associated with id.
   */
  function id(id) {
    return document.getElementById(id);
  }

  /**
   * Returns the element that has the matches the selector passed.
   * @param {string} selector - selector for element
   * @return {object} DOM object associated with selector.
   */
  function qs(selector) {
    return document.querySelector(selector);
  }
})();
