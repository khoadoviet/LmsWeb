'use strict';
(function() {
  const API_URL = '/api/course/:courseid/quizes';

  window.addEventListener('load', init);

  /**
   * TODO - setup the sign-in button on initial page load
   */
  function init() {
    fetch(API_URL,{
        method: "GET"
    })
    .then(statusCheck)
    .then(resp => resp.json())
    .then(addEntry)
    .catch(console.log);

  
    // TODO
  }

  /**
   * TODO
   * signIn - Signs the user in based on username and password inputs
   */
   
   function addEntry(rows) {
    console.log(rows[0]["CourseName"])
    let course = rows[0]["CourseName"];
    let resgister = id("courses")
    let div = document.createElement("div");
    div.className = "list-group";
    div.id = "CourseName";
    div.innerText = course;   
    for (let i = 0; i < rows.length; i++) {
        let quizName = rows[i]["QuizName"];
        
        let a = document.createElement("a");
        a.className = "list-group-item list-group-item-action";
        a.href = "doquiz.html"
        a.id = "doquiz"
        a.innerText = quizName;
        
        div.appendChild(a)
        resgister.appendChild(div);
      }
      document.querySelectorAll("#doquiz").forEach((e) => {
        e.addEventListener("click",doQuizz);
        e.myParam = rows;
     });
  }
  function doQuizz(e) {
    let target = e.target;
    let p = target.parentElement;
    let a = p.children[0].innerText;
    let rows = e.target.myParam;
    let QuizID = ""
    for(let i =0; i< rows.length; i++) {
      let QuizName = rows[i]["QuizName"];
        if(QuizName == a){
          QuizID = rows[i]["QuizID"];
        }
    }
    const d = new Date();
    d.setTime(d.getTime() + (7*24*60*60*1000));
    let expires = "expires="+ d.toUTCString();
    document.cookie = "QuizID" + "=" + QuizID + ";" + expires + ";path=/";
}

  /* ------------------------------ Helper Functions  ------------------------------ */

  /**
   * Helper function to return the response's result text if successful, otherwise
   * returns the rejected Promise result with an error status and corresponding text
   * @param {object} res - response to check for success/error
   * @return {object} - valid response if response was successful, otherwise rejected
   *                    Promise result
   */
  async function statusCheck(res) {
    if (!res.ok) {
      throw new Error(await res.text());
    }
    return res;
  }

  /**
   * Returns the element that has the ID attribute with the specified value.
   * @param {string} id - element ID
   * @return {object} DOM object associated with id.
   */
  function id(id) {
    return document.getElementById(id);
  }

  /**
   * Returns the element that has the matches the selector passed.
   * @param {string} selector - selector for element
   * @return {object} DOM object associated with selector.
   */
  function qs(selector) {
    return document.querySelector(selector);
  }
})();
