"use strict";
const express = require("express");
const multer = require("multer");
const otherMods = require('./modules/announcements');
const getDoquiz = require('./modules/doquiz');
const postDoquiz = require('./modules/postDoquiz');
const login = require("./modules/login");
const logout = require("./modules/logout");
const register = require("./modules/register")
const postReg = require("./modules/postRegister");
const getAllCourses = require("./modules/getAllCourses");
const postAllCourses = require("./modules/postAllCourses");
const getMyCourses = require("./modules/getMyCourses");
const postMyCourses = require("./modules/postMyCourses")
const coursePage = require("./modules/coursePage");
const cookieParser = require("cookie-parser");
const path = require('path');
const app = express();
const cors = require('cors');
app.use(express.json());
app.use(multer().none());
app.use(cookieParser());
app.use(express.static(path.join(__dirname, '../public')));
app.get('/', function(request, response) {
  response.sendFile(path.join(__dirname, '../public', 'index.html'));
});
app.use(cors({
  origin: '*'
}));
app.get("/api/announcements", otherMods.announcements);
app.post("/api/login", login.login);
app.post("/api/logout", logout.logout)
app.get("/api/register",register.register);
app.post("/api/register", postReg.postRegister);
app.get("/api/all/courses", getAllCourses.getAllCourses);
app.post("/api/all/courses", postAllCourses.postAllCourses);
app.get("/api/my/courses", getMyCourses.getMyCourses);
app.post("/api/my/courses", postMyCourses.postMyCourses);
app.get("/api/course/:courseid/quizes", coursePage.coursePage);
app.get("/api/course/:courseid/doquiz/:quizid", getDoquiz.doquiz);
app.post("/api/course/:courseid/doquiz/:quizid", postDoquiz.postDoquiz); 
const PORT = 3000;
app.listen(PORT);