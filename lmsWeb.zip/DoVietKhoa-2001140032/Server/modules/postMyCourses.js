const sqlite3 = require("sqlite3");
const sqlite = require("sqlite");
module.exports.postMyCourses = async function(req, res) {
    res.type("text");
    
    if(req.cookies.Username) {
      try {   
        let db = await getDBConnection();
        let CourseID = req.body.CourseID;
        let sql = "DELETE FROM UserCourse WHERE UserID = (SELECT UserID FROM User WHERE Username = ?) AND CourseID = ?;"
        let courses = await db.all(sql,[req.cookies.Username,CourseID]);
        await db.close();
        res.send(true);
      } catch (error) {
        res.status(500).send("problem with server");
      }
    } else {
        res.send("please login")
    }
  }
  async function getDBConnection() {
    const db = await sqlite.open({
      filename: "database.db",
      driver: sqlite3.Database,
    });
    return db;
  };