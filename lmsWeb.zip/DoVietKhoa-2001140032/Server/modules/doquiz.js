const sqlite3 = require("sqlite3");
const sqlite = require("sqlite");
module.exports.doquiz = async function(req,res) {
    res.type("text");
    if (req.cookies.Username) {
      if (req.cookies.CourseID) {
        if (req.cookies.QuizID) {
          try {
          let QuizID = req.cookies.QuizID;
          let db = await getDBConnection();
          let sql = "SELECT QuestionID, Question FROM Questions INNER JOIN Quizzes ON questions.QuizID = Quizzes.QuizID WHERE Quizzes.QuizID = ?;";
          let Questions = await db.all(sql,QuizID)
          if (Questions.length === 0) {
            res.send("No questions in this quiz")
          } else {
            let query = "SELECT AnswersID, Answer, CorrectAns FROM Answers INNER JOIN Questions ON Answers.QuestionID = Questions.QuestionID WHERE Questions.QuestionID = ?;"
            for(let i = 0; i < Questions.length;i++) {
              let QuestionID = Questions[i]["QuestionID"]
              let dbs = await getDBConnection();
              let Answers = await dbs.all(query,QuestionID);
              let Answer = "Answer";
              Questions[i][Answer] = [...Answers];
  
            }
            await db.close();
            res.json(Questions)
          }
        } catch {
          res.send("error server")
        }
        } else {
          res.send("not found QuizID")
        } 
      } else {
        res.send("Please choose correct course")
      }
    } else {
      res.send("Please login")
    }
  }

  async function getDBConnection() {
    const db = await sqlite.open({
      filename: "database.db",
      driver: sqlite3.Database,
    });
    return db;
  };