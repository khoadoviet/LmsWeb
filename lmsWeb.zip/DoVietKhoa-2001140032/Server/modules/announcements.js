const sqlite3 = require("sqlite3");
const sqlite = require("sqlite");
module.exports.announcements = async function (req, res) {
  
   try {
    res.type("text")
    let sql = "SELECT * FROM Annoucements;";
    let database = await getDBConnection();
    let values = await database.all(sql);
    await database.close();
    res.json(values)
  } catch (error) {
    res.type("text");
    res.status(500).send("Something went wrong on the server.");
  }
  async function getDBConnection() {
    const db = await sqlite.open({
      filename: "database.db",
      driver: sqlite3.Database,
    });
    return db;
  };
}

