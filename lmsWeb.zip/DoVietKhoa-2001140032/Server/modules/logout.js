const sqlite3 = require("sqlite3");
const sqlite = require("sqlite");
module.exports.logout = function(req,res) {
    res.type("text");
    let Cookies = req.cookies;
    if (Cookies) {
      res.clearCookie(Cookies);
      
      res.redirect("/api/annoucements");
    } else {
      
      res.redirect("/api/annoucements");
    }
  }
