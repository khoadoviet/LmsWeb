const sqlite3 = require("sqlite3");
const sqlite = require("sqlite");
module.exports.login = async function(req,res) {
    res.type("text");
    let database = await getDBConnection();
    let Username = req.body.Username;
    let Password = req.body.Password;
    if (Username === undefined || Password === undefined) {
      res.status(400).send("Missing required paramaters userName or password.");
    } else {
      let sql = `SELECT * FROM User WHERE Username = '${Username}' AND Password = '${Password}';`;
      let values = await database.all(sql);
      if (values.length >0) {
            database.close(); 
            res.cookie("Username", Username, { maxAge: 7 * 24 * 60 * 60 * 1000});
            res.send(true);
      } else {
        res.send("Username or password is incorrect")
      }
      
    }
}
async function getDBConnection() {
    const db = await sqlite.open({
      filename: "database.db",
      driver: sqlite3.Database,
    });
    return db;
  };