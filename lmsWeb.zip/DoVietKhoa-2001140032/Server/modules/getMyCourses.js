const sqlite3 = require("sqlite3");
const sqlite = require("sqlite");
module.exports.getMyCourses = async function(req,res) {
    res.type("text");
    try {
      let db = await getDBConnection();
      let sql = "SELECT * FROM Course WHERE CourseID IN (SELECT CourseID FROM UserCourse INNER JOIN User ON UserCourse.UserID = User.UserID WHERE Username = ?)";
      let courses = await db.all(sql,[req.cookies.Username]);
      await db.close();
      let x = JSON.stringify(courses)
      res.send(x);
    } catch (error) {
      res.status(500).send("Something went wrong on the server.");
      
    }
    
  }
  async function getDBConnection() {
    const db = await sqlite.open({
      filename: "database.db",
      driver: sqlite3.Database,
    });
    return db;
  };