const sqlite3 = require("sqlite3");
const sqlite = require("sqlite");
module.exports.postRegister = async function(req, res) {
    let Username = req.body.Username;
    let Password = req.body.Password;
    res.type("text");
    if (Username === undefined || Password === undefined) {
      res.send("Missing required paramaters username or password.");
    } else {
    let database = await getDBConnection();
    let a = "SELECT Username FROM User WHERE Username = ?;";
    let rows = await database.all(a, Username);
    if (rows.length > 0) {
      res.send("User has existed")
    } else {
      let db = await getDBConnection();
      let inserstSql = "INSERT INTO User (Username, Password) VALUES (?,?);";
      await db.all(inserstSql, [Username,Password]);
      res.send("true");
    }
    
  }
    
    }
async function getDBConnection() {
    const db = await sqlite.open({
      filename: "database.db",  
      driver: sqlite3.Database,
    });
    return db;
  };