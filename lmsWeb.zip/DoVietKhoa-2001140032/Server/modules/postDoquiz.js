const sqlite3 = require("sqlite3");
const sqlite = require("sqlite");
module.exports.postDoquiz = async function(req,res){
    res.type("text");
    if(req.cookies.Username) {
      if(req.cookies.CourseID) {
        if(req.cookies.QuizID) {
          try {
            let choice = req.body.answer;
            choice = JSON.parse(choice);
            let db = await getDBConnection();
            let correctAns = "SELECT Questions.QuestionID , AnswersID  from Answers inner join Questions on Answers.QuestionID = Questions.QuestionID  WHERE CorrectAns = 1 and Questions.QuizID = ?;"
            let rowsCorrectAns = await db.all(correctAns,req.cookies.QuizID);
            await db.close();
            let score = 0;
            for(let i = 0; i < rowsCorrectAns.length; i++) {
              for(let j = 0; j < choice.length;j++) {
                if(rowsCorrectAns[i]["QuestionID"] == choice[j]["QuestionID"] && (rowsCorrectAns[i]["AnswersID"] == choice[j]["AnswerID"])) {
                    score++;
                }
              }
            }
            res.json(score);
          } catch (error) {
            res.status(500).send("error server")
          }
        }
      } else {
        res.send("please choose id");
      }
    } else {
      res.send("Please Login");
    }
  }
  async function getDBConnection() {
    const db = await sqlite.open({
      filename: "database.db",
      driver: sqlite3.Database,
    });
    return db;
  };