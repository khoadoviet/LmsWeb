const sqlite3 = require("sqlite3");
const sqlite = require("sqlite");
module.exports.register = async function(req,res) {
    try {
       let db = await getDBConnection();
    let a = "SELECT * FROM User;";
    let users = await db.all(a);
      res.json(users)
    } catch (error) {
      res.type("text");
      res.status(500).send("Something went wrong on the server.");
    }
    
   
  }
async function getDBConnection() {
    const db = await sqlite.open({
      filename: "database.db",
      driver: sqlite3.Database,
    });
    return db;
  };