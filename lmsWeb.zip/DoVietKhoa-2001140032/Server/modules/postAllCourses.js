const sqlite3 = require("sqlite3");
const sqlite = require("sqlite");
module.exports.postAllCourses = async function(req,res) {
    res.type("text");
    if(req.cookies.Username) {
      try {
  
        let db = await getDBConnection();
        let CourseID = req.body.CourseID;
        let sqlUID = "SELECT UserID from User WHERE Username = ?"
        let getOjID = await db.all(sqlUID,req.cookies.Username);
        let values = getOjID["UserID"];
        let sql = "INSERT INTO UserCourse VALUES(?,?);";
        let courses = await db.all(sql,[getOjID[0]["UserID"],CourseID]);
  
        await db.close();
        res.send("true")
      } catch (error) {
        res.status(500).send("problem with server");
      }
    } else {
        res.send("please login")
    }
    
  }
  async function getDBConnection() {
    const db = await sqlite.open({
      filename: "database.db",
      driver: sqlite3.Database,
    });
    return db;
  };