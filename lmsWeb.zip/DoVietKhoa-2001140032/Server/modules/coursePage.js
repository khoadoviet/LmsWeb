const sqlite3 = require("sqlite3");
const sqlite = require("sqlite");
module.exports.coursePage = async function(req,res) {
    res.type("text");    
    if(req.cookies.Username) {
      if(req.cookies.CourseID) {
        try {
        let db = await getDBConnection();
        let sql = "SELECT * FROM Quizzes INNER JOIN Course ON Quizzes.CourseID = Course.CourseID WHERE Quizzes.CourseID = ?;"
        let rows = await db.all(sql,req.cookies.CourseID);
        await db.close();
        res.json(rows)
      } catch {
        res.send("")
      }
      } else {
        res.send("cannot found course")
      }
      
    } else {
      res.send("Please login")
    }
  }
  async function getDBConnection() {
    const db = await sqlite.open({
      filename: "database.db",
      driver: sqlite3.Database,
    });
    return db;
  };